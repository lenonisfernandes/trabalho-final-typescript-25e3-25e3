import { MovieSchemaDriver } from './MovieSchemaDriver';

export type BDSchema = {
    movies: MovieSchemaDriver[];
}

